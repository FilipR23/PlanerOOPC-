﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Planer
{
    class Korisnik
    {
        public string Ime
        { get; set; }
        public string Sifra
        { get; set; }
        public List<Obaveza> Obaveze
        { get; set; }
        public Korisnik(string _Ime, string _Sifra)
        {
            Ime = _Ime;
            Sifra = _Sifra;
            Obaveze = new List<Obaveza>();
        }
    }
}
