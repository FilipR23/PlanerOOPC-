﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace Planer
{
    public partial class Form2 : Form
    {
        List<Korisnik> Korisnici = new List<Korisnik>();
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            JsonSerializerSettings settings = new JsonSerializerSettings { TypeNameHandling = TypeNameHandling.All };
            List<Korisnik> Korisnici = JsonConvert.DeserializeObject<List<Korisnik>>(Properties.Settings.Default.Korisnici, settings);
            if (Korisnici == null)
            {
                Korisnici = new List<Korisnik>();
            }

            this.Korisnici = Korisnici;
        }

        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            JsonSerializerSettings settings = new JsonSerializerSettings { TypeNameHandling = TypeNameHandling.All };
            string korisnik = JsonConvert.SerializeObject(Korisnici, settings);
            Properties.Settings.Default.Korisnici = korisnik;
            Properties.Settings.Default.Save();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txbImeReg.Text))
            {
                MessageBox.Show("Ime ne moze biti prazno");
                return;
            }
            if (string.IsNullOrWhiteSpace(txbSifraReg.Text))
            {
                MessageBox.Show("Sifra ne moze biti prazna");
                return;
            }
            Korisnik korisnik = new Korisnik(txbImeReg.Text, txbSifraReg.Text);
            foreach (var i in Korisnici)
            {
                if (korisnik.Ime == i.Ime)
                {
                    MessageBox.Show("Korisnicko ime je vec zauzeto.");
                    return;
                }
            }
            Korisnici.Add(korisnik);
            this.Close();
            Form1 form1 = new Form1();
            form1.Show();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 form1 = new Form1();
            form1.Show();
        }
    }
}
