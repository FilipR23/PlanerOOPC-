﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Planer
{
    class Globalno
    {
        static readonly Globalno _instance = new Globalno();

        public static Globalno Instance
        {
            get
            {
                return _instance;
            }
        }
        public Korisnik TrenutniKorisnik
        { get; set; } 

        Globalno()
        {
        }
    }
}
