﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace Planer
{
    public partial class Form3 : Form
    {
        List<Korisnik> Korisnici = new List<Korisnik>();
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            JsonSerializerSettings settings = new JsonSerializerSettings { TypeNameHandling = TypeNameHandling.All };
            List<Korisnik> Korisnici = JsonConvert.DeserializeObject<List<Korisnik>>(Properties.Settings.Default.Korisnici, settings);
            if (Korisnici == null)
            {
                Korisnici = new List<Korisnik>();
            }

            this.Korisnici = Korisnici;
            foreach (var item in Globalno.Instance.TrenutniKorisnik.Obaveze)
            {
                listObaveze.Items.Add(item);
                if (item.Rok < DateTime.Now)
                {
                    overdueList.Items.Add(item);
                }
                if (item.Prioritet == 5 && item.Rok - DateTime.Now < new TimeSpan(0, 6, 0, 0))
                {
                    MessageBox.Show($"Rok obaveze {item} se približava kraju");
                }
                else if (item.Prioritet == 4 && item.Rok - DateTime.Now < new TimeSpan(0, 12, 0, 0))
                {
                    MessageBox.Show($"Rok obaveze {item} se približava kraju");
                }
                else if (item.Prioritet == 3 && item.Rok - DateTime.Now < new TimeSpan(1, 0, 0, 0))
                {
                    MessageBox.Show($"Rok obaveze {item} se približava kraju");
                }
                else if (item.Prioritet == 2 && item.Rok - DateTime.Now < new TimeSpan(7, 0, 0, 0))
                {
                    MessageBox.Show($"Rok obaveze {item} se približava kraju");
                }
                else if (item.Prioritet == 1 && item.Rok - DateTime.Now < new TimeSpan(14, 0, 0, 0))
                {
                    MessageBox.Show($"Rok obaveze {item} se približava kraju");
                }
            }
        }
        private void Form3_FormClosed(object sender, FormClosedEventArgs e)
        {
            foreach (Korisnik k in Korisnici)
            {
                if (k.Ime == Globalno.Instance.TrenutniKorisnik.Ime)
                {
                    k.Ime = Globalno.Instance.TrenutniKorisnik.Ime;
                    k.Sifra = Globalno.Instance.TrenutniKorisnik.Sifra;
                    k.Obaveze = Globalno.Instance.TrenutniKorisnik.Obaveze;
                }
            }
            JsonSerializerSettings settings = new JsonSerializerSettings { TypeNameHandling = TypeNameHandling.All };
            string korisnik = JsonConvert.SerializeObject(Korisnici, settings);
            Properties.Settings.Default.Korisnici = korisnik;
            Properties.Settings.Default.Save();
            Application.Exit();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txbNazivAdd.Text))
            {
                MessageBox.Show("Obaveza mora imati naziv");
                return;
            }
            if (string.IsNullOrEmpty(txbKategorijaAdd.Text))
            {
                MessageBox.Show("Kategorija mora imati naziv");
                return;
            }
            if (string.IsNullOrEmpty(txbRokAdd.Text) || !DateTime.TryParse(txbRokAdd.Text, out DateTime t))
            {
                MessageBox.Show("Nije validan datum (Unesite datum u obliku mm/dd/yyyy)");
                return;
            }
            if (!int.TryParse(txbPrioritetAdd.Text, out int test))
            {
                MessageBox.Show("Prioritet se mora uneti i biti u opsegu od 1 do 5.");
                return;
            }

            if (string.IsNullOrEmpty(txbPrioritetAdd.Text) || Convert.ToInt32(txbPrioritetAdd.Text) < 1 || Convert.ToInt32(txbPrioritetAdd.Text) > 5)
            {
                MessageBox.Show("Prioritet se mora uneti i biti u opsegu od 1 do 5.");
                return;
            }

            Obaveza obaveza = new Obaveza(txbNazivAdd.Text, txbKategorijaAdd.Text, Convert.ToDateTime(txbRokAdd.Text), Convert.ToInt32(txbPrioritetAdd.Text));
            Globalno.Instance.TrenutniKorisnik.Obaveze.Add(obaveza);
            listObaveze.Items.Add(obaveza);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            for(int i = 0; i < Globalno.Instance.TrenutniKorisnik.Obaveze.Count; i++)
            {
                if (Globalno.Instance.TrenutniKorisnik.Obaveze[i].Equals(listObaveze.SelectedItem))
                {
                    listObaveze.Items.Remove(Globalno.Instance.TrenutniKorisnik.Obaveze[i]);
                    Globalno.Instance.TrenutniKorisnik.Obaveze.Remove(Globalno.Instance.TrenutniKorisnik.Obaveze[i]);
                }
            }
        }

        private void txbSearch_TextChanged(object sender, EventArgs e)
        {
        }

        private void btnSort_Click(object sender, EventArgs e)
        {
            List<Obaveza> sortirani = new List<Obaveza>();
            foreach (Obaveza o in Globalno.Instance.TrenutniKorisnik.Obaveze)
            {
                if (o.Kategorija == txbKategorijaSort.Text)
                {
                    sortirani.Add(o);
                }
            }
            listObaveze.Items.Clear();
            foreach (var item in sortirani)
            {
                listObaveze.Items.Add(item);
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            foreach (Obaveza o in Globalno.Instance.TrenutniKorisnik.Obaveze)
            {
                if (string.IsNullOrWhiteSpace(txbRokEdit.Text))
                {
                    MessageBox.Show("Rok mora imati vrednost");
                    return;
                }
                if (o.Equals(listObaveze.SelectedItem))
                {
                    o.Rok = Convert.ToDateTime(txbRokEdit.Text);
                    listObaveze.Items.Remove(listObaveze.SelectedItem);
                    listObaveze.Items.Add(o);
                }
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            listObaveze.ClearSelected();

            int index = listObaveze.FindString(txbSearch.Text);

            if (index < 0)
            {
                MessageBox.Show("Item not found.");
                listObaveze.Text = String.Empty;
            }
            else
            {
                listObaveze.SelectedIndex = index;
            }
            if (string.IsNullOrEmpty(txbSearch.Text))
            {
                listObaveze.Items.Clear();
                foreach (var item in Globalno.Instance.TrenutniKorisnik.Obaveze)
                {
                    listObaveze.Items.Add(item);
                }
            }
        }
    }
}
