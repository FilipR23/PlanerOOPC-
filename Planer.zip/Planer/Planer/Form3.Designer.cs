﻿namespace Planer
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.overdueList = new System.Windows.Forms.ListBox();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.listObaveze = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.txbSearch = new System.Windows.Forms.TextBox();
            this.btnSort = new System.Windows.Forms.Button();
            this.txbRokEdit = new System.Windows.Forms.TextBox();
            this.txbKategorijaSort = new System.Windows.Forms.TextBox();
            this.txbNazivAdd = new System.Windows.Forms.TextBox();
            this.txbKategorijaAdd = new System.Windows.Forms.TextBox();
            this.txbRokAdd = new System.Windows.Forms.TextBox();
            this.txbPrioritetAdd = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // overdueList
            // 
            this.overdueList.FormattingEnabled = true;
            this.overdueList.Location = new System.Drawing.Point(52, 68);
            this.overdueList.Name = "overdueList";
            this.overdueList.Size = new System.Drawing.Size(120, 95);
            this.overdueList.TabIndex = 0;
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.Location = new System.Drawing.Point(546, 52);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.TabIndex = 1;
            // 
            // listObaveze
            // 
            this.listObaveze.FormattingEnabled = true;
            this.listObaveze.Location = new System.Drawing.Point(213, 105);
            this.listObaveze.Name = "listObaveze";
            this.listObaveze.Size = new System.Drawing.Size(301, 251);
            this.listObaveze.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(210, 82);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Obaveze:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(223, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Obaveze koje su trebale da se završe do sad:";
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(68, 388);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(100, 23);
            this.btnAdd.TabIndex = 5;
            this.btnAdd.Text = "Dodaj obavezu";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(413, 372);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(91, 23);
            this.btnDelete.TabIndex = 6;
            this.btnDelete.Text = "Obriši obavezu";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.Location = new System.Drawing.Point(586, 398);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(83, 23);
            this.btnEdit.TabIndex = 7;
            this.btnEdit.Text = "Promeni rok";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // txbSearch
            // 
            this.txbSearch.Location = new System.Drawing.Point(334, 79);
            this.txbSearch.Name = "txbSearch";
            this.txbSearch.Size = new System.Drawing.Size(100, 20);
            this.txbSearch.TabIndex = 8;
            this.txbSearch.TextChanged += new System.EventHandler(this.txbSearch_TextChanged);
            // 
            // btnSort
            // 
            this.btnSort.Location = new System.Drawing.Point(546, 285);
            this.btnSort.Name = "btnSort";
            this.btnSort.Size = new System.Drawing.Size(123, 23);
            this.btnSort.TabIndex = 9;
            this.btnSort.Text = "Sortiraj po kategoriji";
            this.btnSort.UseVisualStyleBackColor = true;
            this.btnSort.Click += new System.EventHandler(this.btnSort_Click);
            // 
            // txbRokEdit
            // 
            this.txbRokEdit.Location = new System.Drawing.Point(573, 372);
            this.txbRokEdit.Name = "txbRokEdit";
            this.txbRokEdit.Size = new System.Drawing.Size(116, 20);
            this.txbRokEdit.TabIndex = 10;
            // 
            // txbKategorijaSort
            // 
            this.txbKategorijaSort.Location = new System.Drawing.Point(556, 259);
            this.txbKategorijaSort.Name = "txbKategorijaSort";
            this.txbKategorijaSort.Size = new System.Drawing.Size(100, 20);
            this.txbKategorijaSort.TabIndex = 11;
            // 
            // txbNazivAdd
            // 
            this.txbNazivAdd.Location = new System.Drawing.Point(68, 285);
            this.txbNazivAdd.Name = "txbNazivAdd";
            this.txbNazivAdd.Size = new System.Drawing.Size(100, 20);
            this.txbNazivAdd.TabIndex = 12;
            // 
            // txbKategorijaAdd
            // 
            this.txbKategorijaAdd.Location = new System.Drawing.Point(68, 312);
            this.txbKategorijaAdd.Name = "txbKategorijaAdd";
            this.txbKategorijaAdd.Size = new System.Drawing.Size(100, 20);
            this.txbKategorijaAdd.TabIndex = 13;
            // 
            // txbRokAdd
            // 
            this.txbRokAdd.Location = new System.Drawing.Point(68, 335);
            this.txbRokAdd.Name = "txbRokAdd";
            this.txbRokAdd.Size = new System.Drawing.Size(100, 20);
            this.txbRokAdd.TabIndex = 14;
            // 
            // txbPrioritetAdd
            // 
            this.txbPrioritetAdd.Location = new System.Drawing.Point(68, 362);
            this.txbPrioritetAdd.Name = "txbPrioritetAdd";
            this.txbPrioritetAdd.Size = new System.Drawing.Size(100, 20);
            this.txbPrioritetAdd.TabIndex = 15;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(27, 290);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 13);
            this.label3.TabIndex = 16;
            this.label3.Text = "Naziv";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 315);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 13);
            this.label4.TabIndex = 17;
            this.label4.Text = "Kategorija";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(35, 338);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(27, 13);
            this.label5.TabIndex = 18;
            this.label5.Text = "Rok";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(20, 365);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(42, 13);
            this.label6.TabIndex = 19;
            this.label6.Text = "Prioritet";
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(439, 77);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 20;
            this.btnSearch.Text = "Pretrazi";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txbPrioritetAdd);
            this.Controls.Add(this.txbRokAdd);
            this.Controls.Add(this.txbKategorijaAdd);
            this.Controls.Add(this.txbNazivAdd);
            this.Controls.Add(this.txbKategorijaSort);
            this.Controls.Add(this.txbRokEdit);
            this.Controls.Add(this.btnSort);
            this.Controls.Add(this.txbSearch);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listObaveze);
            this.Controls.Add(this.monthCalendar1);
            this.Controls.Add(this.overdueList);
            this.Name = "Form3";
            this.Text = "Form3";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form3_FormClosed);
            this.Load += new System.EventHandler(this.Form3_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox overdueList;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
        private System.Windows.Forms.ListBox listObaveze;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.TextBox txbSearch;
        private System.Windows.Forms.Button btnSort;
        private System.Windows.Forms.TextBox txbRokEdit;
        private System.Windows.Forms.TextBox txbKategorijaSort;
        private System.Windows.Forms.TextBox txbNazivAdd;
        private System.Windows.Forms.TextBox txbKategorijaAdd;
        private System.Windows.Forms.TextBox txbRokAdd;
        private System.Windows.Forms.TextBox txbPrioritetAdd;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnSearch;
    }
}