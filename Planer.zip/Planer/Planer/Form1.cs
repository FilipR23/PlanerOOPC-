﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace Planer
{
    public partial class Form1 : Form
    {
        List<Korisnik> Korisnici = new List<Korisnik>();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Shown(object sender, EventArgs e)
        {
            JsonSerializerSettings settings = new JsonSerializerSettings { TypeNameHandling = TypeNameHandling.All };
            List<Korisnik> Korisnici = JsonConvert.DeserializeObject<List<Korisnik>>(Properties.Settings.Default.Korisnici, settings);
            if (Korisnici == null)
            {
                Korisnici = new List<Korisnik>();
            }
            tbxSifra.PasswordChar = '*';
            this.Korisnici = Korisnici;
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            JsonSerializerSettings settings = new JsonSerializerSettings { TypeNameHandling = TypeNameHandling.All };
            string korisnik = JsonConvert.SerializeObject(Korisnici, settings);
            Properties.Settings.Default.Korisnici = korisnik;
            Properties.Settings.Default.Save();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            foreach (var korisnik in Korisnici)
            {
                if (korisnik.Ime == tbxIme.Text && korisnik.Sifra == tbxSifra.Text)
                {
                    Globalno.Instance.TrenutniKorisnik = korisnik;
                }
            }
            if (Globalno.Instance.TrenutniKorisnik == null)
            {
                MessageBox.Show("Korisnik nije pronadjen");
                return;
            }
            this.Hide();
            Form3 form3 = new Form3();
            form3.Show();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 form2 = new Form2();
            form2.Show();
        }
        private void label2_Click(object sender, EventArgs e)
        {
            string hostName = Dns.GetHostName();
            string myIP = Dns.GetHostByName(hostName).AddressList[0].ToString();
            MessageBox.Show(myIP);
        }
    }
}
