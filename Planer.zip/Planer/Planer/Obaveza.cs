﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Planer
{
    class Obaveza
    {
        public string Naziv
        { get; set; }
        public string Kategorija
        { get; set; }
        public DateTime Rok
        { get; set; }
        public int Prioritet 
        { get; set; }
        public Obaveza() { }
        public Obaveza(string _naziv, string _kateogrija, DateTime _rok, int _prioritet)
        {
            Naziv = _naziv;
            Kategorija = _kateogrija;
            Rok = _rok;
            Prioritet = _prioritet;
        }
        public override string ToString()
        {
            return $"{Naziv}, {Kategorija}, {Rok}"; 
        }
    }
}
